////获取应用实例
var app = getApp()
Page({
  data: {
    userInfo: {},
    orderlist:{},
    orderdetail:{},
    hideflg:true
  },
getdetail:function(event){
       var that = this;
  if (that.data.hideflg){
      that.setData({
      hideflg:false
      });
  }
  else{
      that.setData({
      hideflg:true
      });
  }
  //console.log(event.currentTarget.dataset.orderid)

  wx.request({
      url: 'https://dev.mbeta.pw/api/WebAPI/ws_SearchOrderDetail/json',      data: {
        OrderID:event.currentTarget.dataset.orderid
      },
      header: {
          'content-type': 'application/json'
      },
      success: function(res) {
          //console.log(res.data.ResultSets[0]);
            
         that.setData({
            orderdetail:res.data.ResultSets[0]
        });  
        }     
  
    });  

},
  onLoad: function () {
    // console.log('CustomerPageonLoad');
     var that = this;
     that.setData(
       {
         userInfo:app.globalData.userInfo
       }
     );
        wx.request({
      url: 'https://dev.mbeta.pw/api/WebAPI/ws_SearchOrder/json',      data: {
        custcode:app.globalData.wxopenid,
        FFlag:8
      },
      header: {
          'content-type': 'application/json'
      },
      success: function(res) {
            // console.log(res.data.ResultSets[0]);
            
         that.setData({
            orderlist:res.data.ResultSets[0]
        });  
        }     
  
    });  
  },
   onReady: function() { 
  // Do something when page ready. 
     var that = this; 
 }
})
