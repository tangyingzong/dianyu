var app = getApp();
Page({
  data:{
    // text:"这是一个页面"
    products: [],
    ItemShow:{
      productList:[],
      productBlock:[]
    },
     imgUrls: [

       "../../img/swiper1.jpg",
        "../../img/swiper2.jpg",
         "../../img/swiper3.jpg"
     ],
    indicatorDots: true,
    autoplay: true,
    interval: 3000,
    duration: 1000,
    winWidth: 0,  
    winHeight: 0, 
    currentTab: 0,
    currentProduct:[]
  },

  onLoad:function() {
      var that = this; 
    app.getUserInfo(function(userInfo){
      //更新数据
      that.setData({
        userInfo:userInfo
      })
    });
    wx.request({
      url:  'https://dev.mbeta.pw/api/WebAPI/ws_SearchProducts/json',      data: {},
      header: {
          'content-type': 'application/json'
      },
      success: function(res) {
        // console.log(res.data.ResultSets[0]);
        that.setData({

            products:res.data.ResultSets[0]
        });
        that.setData({
          ItemShow:{
            productList:res.data.ResultSets[0],
            productBlock:res.data.ResultSets[0]
          }
        });
       
    // console.log(that.data.ItemShow);
      }
    });
     wx.getSystemInfo( {  
  
      success: function( res ) {  
        that.setData( {  
          winWidth: res.windowWidth,  
          winHeight: res.windowHeight  
        });  
      }  
  
    }); 

  },
   /** 
     * 滑动切换tab 
     */  
  bindChange: function( e ) {  
  
    var that = this;  
    that.setData( { currentTab: e.detail.current });  
  
  },  
  /** 
   * 点击tab切换 
   */  
  swichNav: function( e ) {  
  
    var that = this;  
  
    if( this.data.currentTab === e.target.dataset.current ) {  
      return false;  
    } else {  
      that.setData( {  
        currentTab: e.target.dataset.current  
      })  
    }  
  } 

  

})

