// pages/search/search.js


//获取应用实例
var WxSearch = require('../template/wxSearch/wxSearch.js');
var app = getApp();
Page({
  data: {
    // wxSearchData:{
    //   view:{
    //     isShow: true
    //   }
    // }
    hisArryLength:4,
    ItemShow:{productList:[]}
  },
  onLoad: function () {
    console.log('onLoad')
    var that = this
    //初始化的时候渲染wxSearchdata
    WxSearch.init(that,60,['单店','连锁店','旗舰版','网店','建站']);
    WxSearch.initMindKeys(['单店','连锁店','旗舰版','网店','建站']);
  },
  wxSearchFn: function(e){
    var that = this
    ConfirmSearch(e,that);
   
    
  },
  wxSearchConfirm:function(e){
    var that = this
    ConfirmSearch(e,that);
  },
  wxSearchInput: function(e){
    var that = this
    WxSearch.wxSearchInput(e,that);
   
  },
  wxSerchFocus: function(e){
    var that = this
    WxSearch.wxSearchFocus(e,that);
  },
  wxSearchBlur: function(e){
    var that = this
    WxSearch.wxSearchBlur(e,that);
    
  },
  wxSearchKeyTap:function(e){
    var that = this
    WxSearch.wxSearchKeyTap(e,that);
    ConfirmSearch(e,that);
  },
  wxSearchDeleteKey: function(e){
    var that = this
    WxSearch.wxSearchDeleteKey(e,that);
  },
  wxSearchDeleteAll: function(e){
    var that = this;
    WxSearch.wxSearchDeleteAll(that);
  },
  wxSearchTap: function(e){
    var that = this
    WxSearch.wxSearchHiddenPancel(that);
  }
});
function ConfirmSearch(e,that){
//  console.log("confirm");
//  console.log(that.data.wxSearchData.value);
    var hislong=that.data.hisArryLength;
    WxSearch.wxSearchAddHisKey(that,hislong);
    wx.request({
       url:  'https://dev.mbeta.pw/api/WebAPI/ws_SearchProducts_ByComments/json',      
       data: {comments:that.data.wxSearchData.value},
      header: {
          'content-type': 'application/json'
      },
      success: function(res){
        // success
        // console.log(res.data.ResultSets[0]);
        that.setData({
          ItemShow:{
            productList:res.data.ResultSets[0],
          }
        });
      }
    });
}