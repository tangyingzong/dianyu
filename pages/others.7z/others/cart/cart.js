// pages/cart/cart.js
var app = getApp();
var Functions = require('../template/Functions.js');
Page({
  data:{
    userInfo: {},
    CartData:{
      CartList:[],
      Amt:0,
      sumQTY:0,
      },
    RemoveData:{
      startX:0,
      startY:0,
      endX:0,
      endY:0,
      key:false
    },
    ModalHid:{
      ModalSingle:true,
      ModalAll:true
      },

    RemoveID:null
     
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var that = this;
     that.setData(
       {
         userInfo:app.globalData.userInfo
       }
     );
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(options){
    // 页面显示
    // console.log("Cart on show!")
    var that=this;
    Functions.searchCart(that,-1);
  },
  onBack:function(){
    // console.log("Cart on back!")
    var that=this;
    Functions.searchCart(that,-1);
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  QtyMin_click:function(e){
    var that=this;
    var QTY;
    var list=that.data.CartData.CartList;
    var dataID=e.currentTarget.dataset.minid;
    var current=Functions.SearchList(list,'ProductID',dataID);
    // console.log(current);
    if(current.result==-1){console.log("购物车减错误");}
    else{
      if(current.QTY>1){
      QTY=current.QTY-1;
      Functions.saveCart(that,dataID,QTY );}
      else{ 
        var ModalHid=that.data.ModalHid;
        ModalHid.ModalSingle=false; 
        this.setData({
        RemoveID:dataID,
        ModalHid:ModalHid
        });}
      }
  },
  QtyAdd_click:function(e){
    var that=this;
    var QTY;
    var list=that.data.CartData.CartList;
    var dataID=e.currentTarget.dataset.addid;
    var current=Functions.SearchList(list,'ProductID',dataID);
    // console.log(current);
    if(current.result==-1){console.log("购物车加错误");}
    else{QTY=current.QTY+1;
    Functions.saveCart(that,dataID,QTY );}
  },
  drawerStart:function(e){
    var that=this;
    var touch=e.touches[0];
    var remData=that.data.RemoveData;
    remData.startX=touch.clientX;
    remData.startY=touch.clientY;
    remData.key=true;
    that.setData({
      RemoveData:remData
    });
    //   this.setData({
    //   RemoveData:{
    //   startX:touch.clientX,
    //   startY:touch.clientY,
    //   key:true
    //   }
    // });
  },
  drawerMove:function(e){
    // console.log('drawerMove');
    var that=this;
    var remData=that.data.RemoveData;
    var CartList=that.data.CartData.CartList;
    
    // console.log(e);
    
    var dataID=e.currentTarget.id;
     
    if(remData.key){
      var touch=e.touches[0];   
      remData.endX=touch.clientX;
      remData.endY=touch.clientY;
      that.setData({
        RemoveData:remData
      });
      // that.setData({
      //   RemoveData:{
      // endX:touch.clientX,
      // endY:touch.clientY,
      // }
      // });
      remData=that.data.RemoveData;
      var Xst=remData.startX;var Yst=remData.startY;var Xend=remData.endX;var Yend=remData.endY;
      var xAbs=(Xst-Xend)>0?(Xst-Xend):-(Xst-Xend);
      var yAbs=(Yst-Yend)>0?(Yst-Yend):-(Yst-Yend);
      if(xAbs>=yAbs){
        // 有效横向滑动
        if(remData.startX-remData.endX>=5)
        {// 左滑
        
         for(var key in CartList){
           if (CartList[key].ProductID==dataID)
           { 
             CartList[key].right="15%";
            //  CartList[key].hidden="false";
             that.setData({
               CartData:{
                 CartList:CartList
                 }
             });
            //  console.log(that.data.CartData.CartList);
           }
         }
      }
      else if (remData.endX-remData.startX>=5){
        // 右滑
        for(var key in CartList){
           if (CartList[key].ProductID==dataID)
           { 
             CartList[key].right="0";
            //  CartList[key].hidden="true";
             that.setData({
               CartData:{
                 CartList:CartList
                 }
             });
           }
         }
      }
    }
 }
},
tapRemove:function(e){
  var that=this;
  var ModalHid=that.data.ModalHid;
  ModalHid.ModalSingle=false;
  that.setData({
    RemoveID:e.currentTarget.dataset.id,
    ModalHid:ModalHid
  });
 
},
ConfirmRemove:function(e){
  var that=this;
  var dataID=that.data.RemoveID;
  Functions.saveCart(that,dataID,-1);
  var currentPage=getCurrentPages();
  if((typeof(currentPage[0].onBack))=='function')
      {currentPage[0].onBack();}
  var ModalHid=that.data.ModalHid;
  ModalHid.ModalSingle=true;
  that.setData({
     ModalHid:ModalHid,
    RemoveID:null
  });
},
CancelRemove:function(e){
  var that=this;
  var CartList=that.data.CartData.CartList;
  for(var key in CartList){CartList[key].right="0";}

  var ModalHid=that.data.ModalHid;
  ModalHid.ModalSingle=true;
  that.setData({
     ModalHid:ModalHid,
     CartData:{
                 CartList:CartList
                 }
  });
},
ManualQTY:function(e){
  var that=this;
  var dataID=e.currentTarget.dataset.manqtyid;
  var currentQTY=e.detail.value;
  Functions.saveCart(that,dataID,currentQTY);
  var currentPage=getCurrentPages();
  if((typeof(currentPage[0].onBack))=='function')
      {currentPage[0].onBack();}
},
btn_clearCart_click:function(e){
    var that=this;
    var ModalHid=that.data.ModalHid;
    ModalHid.ModalAll=false;
 
    that.setData({
    RemoveID:e.currentTarget.dataset.id,
    ModalHid:ModalHid
  });    
},
ConfirmRemoveAll:function(e){
  var that=this;
  var CartList=that.data.CartData.CartList;
  for(var key in CartList){
    var id=CartList[key].ProductID;
    Functions.saveCart(that,id,-1);
  }
  var ModalHid=that.data.ModalHid;
    ModalHid.ModalAll=true;
  that.setData({
    ModalHid:ModalHid
  });
  },
CancelRemoveAll:function(e){
  var that=this;
  var ModalHid=that.data.ModalHid;
    ModalHid.ModalAll=true;
  that.setData({
    ModalHid:ModalHid
  });
},
btn_submit_click:function(){

//sp_GenerateOrder
}

  
});
