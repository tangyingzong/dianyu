////获取应用实例
var app = getApp();
var Functions = require('../template/Functions.js');
Page({
  data: {
    userInfo: {},
    ShowData:{
        ShowDataList:{}
        },
    CartData:{
      CartList:[],
      Amt:0,
      sumQTY:0,
      }
  },
onLoad: function () {
    // console.log('CustomerPageonLoad');
     var that = this;
     that.setData(
       {
         userInfo:app.globalData.userInfo
       }
     );

        wx.request({
      url: 'https://dev.mbeta.pw/api/WebAPI/ws_SearchCustFavorite_ExistsOrNot/json',      data: {
        custcode:app.globalData.wxopenid,
        FFlag:8
      },
      header: {
          'content-type': 'application/json'
      },
      success: function(res) {
             console.log(res.data.ResultSets[0]);
            
         that.setData({
           ShowData:{
            ShowDataList:res.data.ResultSets[0]
           }
        });  
        }     
  
    });  
  },
  onShow:function(options){
    // 页面显示
    // console.log("Cart on show!")
    var that=this;
    Functions.searchCart(that,-1);
  },
   onReady: function() { 
  // Do something when page ready. 
     var that = this; 
 },
QtyAdd_click:function(e){
    var that=this;
    var QTY;
    var list=that.data.CartData.CartList;
    var dataID=e.currentTarget.dataset.addid;
    console.log(dataID);
    var current=Functions.SearchList(list,'ProductID',dataID);
    // console.log(current);
    if(current.result==-1){Functions.saveCart(that,dataID,1);}
    else{QTY=current.QTY+1;
    Functions.saveCart(that,dataID,QTY );}
  }
})
